<?php

// Inclui a inicialização (sessão, conexão $pdo e funções CRUD)
require_once __DIR__ . "/init.php";

$busca    = '';
$areas    = [];
$openOnly = false;

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['filtrar'])) {
    $busca    = trim($_GET['buscaFiltro'] ?? '');
    $areas    = isset($_GET['area']) && is_array($_GET['area']) ? $_GET['area'] : [];
    $openOnly = isset($_GET['open']);
    $sort     = $_GET['sort'] ?? 'featured';
}

if ($busca !== '') {
    $campanhas = readAll($pdo, "campanhas", "nome LIKE ?", ["%{$busca}%"]);
} else {
    $campanhas = readAll($pdo, "campanhas");
}

$instituicoes = readAll($pdo, "instituicoes");
$inscricoes   = readAll($pdo, "inscricoes");

if (!empty($areas) || $openOnly) {
    $campanhasFiltradas = [];
    
    foreach ($campanhas as $c) {
        $manter = true;

        if ($openOnly && $c['status'] !== 'ativa') {
            $manter = false;
        }

        if ($manter && !empty($areas)) {
            // LÊ O NOVO VALOR: Usa o 'tipo' da campanha vindo do banco
            $tipoDaCampanha = isset($c['tipo']) ? mb_strtolower($c['tipo']) : '';
            
            // Remove acentos (saúde -> saude, educação -> educacao) para o filtro funcionar
            $tipoNormalizado = str_replace(
                ['á', 'é', 'í', 'ó', 'ú', 'ç', 'ã', 'õ', 'â', 'ê', 'ô'], 
                ['a', 'e', 'i', 'o', 'u', 'c', 'a', 'o', 'a', 'e', 'o'], 
                $tipoDaCampanha
            );
            
            if (!in_array($tipoNormalizado, $areas)) {
                $manter = false;
            }
        }

        if ($manter) {
            $campanhasFiltradas[] = $c;
        }
    }
    
    $campanhas = $campanhasFiltradas;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Oportunidades — VolunteerConnect</title>
    <link rel="stylesheet" href="css/oportunidades.css">
    <script src="app.js" defer></script>
</head>

<body>
    <header class="site-header">
        <div class="container header-inner">
            <a class="brand" href="index.php">
                <img src="imagens/logo.png" alt="">
                <span>Volunteer<em>Connect</em></span>
            </a>
            <button class="menu-toggle" type="button" aria-expanded="false" aria-label="Abrir menu">☰</button>
            <nav class="main-nav">
                <a href="oportunidades.php" aria-current="page">Oportunidades</a>
                <a href="instituicoes.php">Instituições</a>
                <a href="como-funciona.php">Como funciona</a>
                <a href="sobre.php">Sobre</a>
            </nav>
            <div class="header-actions">
                <a class="btn btn-light btn-small" href="login.php">Entrar</a>
                <a class="btn btn-primary btn-small" href="cadastro-e-campanha.php">Cadastrar-se</a>
            </div>
        </div>
    </header>

    <main>
        <div class="container">
            <div class="page-heading">
                <span class="eyebrow">Encontre a sua causa</span>
                <h1>Oportunidades de voluntariado</h1>
                <p>Explore projetos, conheça instituições e escolha uma ação que combine com os seus interesses e rotina.</p>
            </div>
            
            <aside class="filter-panel">
                <form id="filters" method="GET" action="oportunidades.php">   
                    <input type="hidden" name="filtrar" value="1">
                    <h2>Filtros</h2>

                    <div class="filter-group">
                        <h3>Pesquisar oportunidade</h3>
                        <div class="form-field">
                            <input 
                                id="buscaFiltro" 
                                name="buscaFiltro" 
                                type="search" 
                                placeholder="Nome da campanha ou instituição"
                                value="<?php echo htmlspecialchars($busca); ?>"
                            >
                        </div>
                    </div>

                    <div class="filter-group">
                        <h3>Área de atuação</h3>
                        <label class="filter-option">
                            <input type="checkbox" name="area[]" value="educacao" <?php echo in_array('educacao', $areas) ? 'checked' : ''; ?>> Educação
                        </label>
                        <label class="filter-option">
                            <input type="checkbox" name="area[]" value="tecnologia" <?php echo in_array('tecnologia', $areas) ? 'checked' : ''; ?>> Tecnologia
                        </label>
                        <label class="filter-option">
                            <input type="checkbox" name="area[]" value="saude" <?php echo in_array('saude', $areas) ? 'checked' : ''; ?>> Saúde
                        </label>
                    </div>

                    <div class="filter-group">
                        <label class="filter-option">
                            <input id="filter-open" name="open" value="1" type="checkbox" <?php echo $openOnly ? 'checked' : ''; ?>> Apenas vagas abertas
                        </label>
                    </div>

                    <div>
                        <button class="btn btn-primary btn-block" type="submit">Aplicar filtros</button>
                        <a class="btn btn-outline btn-block" href="oportunidades.php">Limpar filtros</a>
                    </div>
                </form>
            </aside>

            <section>
                <div class="listing-topline">
                    <p id="results-count" aria-live="polite">A exibir <?php echo count($campanhas); ?> oportunidades</p>
                </div>
                
                <?php if (!empty($campanhas)) { ?>
                    <div class="listing-cards" id="opportunity-results">
                        <?php 
                        foreach ($campanhas as $c) {
                            $inst_nome     = "Instituição não informada";
                            $inst_endereco = "Localização não cadastrada";

                            foreach ($instituicoes as $i) {
                                if ($i['id'] == $c['id_instituicao']) {
                                    $inst_nome     = $i['nome'];
                                    $inst_endereco = $i['endereco'];
                                    break;
                                }
                            }

                            $vagas_preenchidas = 0;
                            foreach ($inscricoes as $ins) {
                                if ($ins['id_campanha'] == $c['id'] && $ins['status'] !== 'cancelado') {
                                    $vagas_preenchidas++;
                                }
                            }

                            $vagas_totais = (int) ($c['vagasTotais'] ?? 0);
                            $porcentagem  = $vagas_totais > 0 ? min(100, round(($vagas_preenchidas / $vagas_totais) * 100)) : 0;

                            // Le o "tipo" da campanha
                            $tipo_campanha = isset($c['tipo']) ? mb_strtolower($c['tipo']) : 'geral';
                            
                            $tipoNormalizado = str_replace(
                                ['á', 'é', 'í', 'ó', 'ú', 'ç', 'ã', 'õ', 'â', 'ê', 'ô'], 
                                ['a', 'e', 'i', 'o', 'u', 'c', 'a', 'o', 'a', 'e', 'o'], 
                                $tipo_campanha
                            );

                            $classe_capa = "cover-education"; // Padrão
                            $icone       = "📚"; // Padrão
                            $rotulo_area = ucfirst($tipo_campanha); // Mostra como está no banco (ex: "Saúde")
                        ?>
                            <article class="opportunity-card" 
                                    data-title="<?php echo htmlspecialchars(mb_strtolower($c['nome'])); ?>" 
                                    data-category="<?php echo htmlspecialchars($tipo_campanha); ?>" 
                                    data-location="<?php echo htmlspecialchars(mb_strtolower($inst_endereco)); ?>" 
                                    data-status="<?php echo htmlspecialchars($c['status']); ?>">
                                
                                <div class="card-cover <?php echo $classe_capa; ?>">
                                    <div class="cover-icon"><?php echo $icone; ?></div>
                                    <span class="pill"><?php echo htmlspecialchars($rotulo_area); ?></span>
                                </div>

                                <div class="card-body">
                                    <h3><?php echo htmlspecialchars($c['nome']); ?></h3>
                                    <p class="card-org"><?php echo htmlspecialchars($inst_nome); ?> · <?php echo htmlspecialchars($inst_endereco); ?></p>
                                    
                                    <div class="card-meta">
                                        <span>📍 Presencial</span>
                                        <span>Status: <strong><?php echo htmlspecialchars(ucfirst($c['status'])); ?></strong></span>
                                    </div>

                                    <p class="muted" style="font-size:.82rem">
                                        <?php echo htmlspecialchars($c['descricao']); ?>
                                    </p>

                                    <div class="card-progress">
                                        <div class="progress-label">
                                            <span><?php echo $vagas_preenchidas; ?> de <?php echo $vagas_totais; ?> vagas preenchidas</span>
                                            <strong><?php echo $porcentagem; ?>%</strong>
                                        </div>
                                        <div class="progress-track">
                                            <span style="width: <?php echo $porcentagem; ?>%;"></span>
                                        </div>
                                    </div>

                                    <div class="card-actions">
                                        <span class="status">
                                            <?php echo ($c['status'] === 'ativa') ? 'Vagas abertas' : ucfirst($c['status']); ?>
                                        </span>
                                        <a class="btn btn-primary btn-small" href="detalhes-oportunidade.php?id=<?php echo $c['id']; ?>">Ver detalhes</a>
                                    </div>
                                </div>
                            </article>
                        <?php } ?>
                    </div>
                <?php } else { ?>
                    <div class="empty-state" id="empty-state" style="<?php echo empty($campanhas) ? 'display:block;' : ''; ?>">
                        <strong>Nenhuma oportunidade encontrada</strong>
                        <p class="muted">Tente alterar os filtros ou pesquisar por outro termo.</p>
                    </div>
                <?php } ?>
            </section>
        </div>
    </main>

    <footer class="site-footer">
        <div class="container">
            <div class="footer-top">
                <div class="footer-brand">
                    <a class="brand" href="index.php">
                        <img src="imagens/logo.png" alt="">
                        <span>Volunteer<em>Connect</em></span>
                    </a>
                    <p>A conectar pessoas e boas causas.</p>
                </div>
                <div class="footer-col">
                    <h3>Explorar</h3>
                    <a href="oportunidades.php">Oportunidades</a>
                    <a href="instituicoes.php">Instituições</a>
                </div>
                <div class="footer-col">
                    <h3>Conheça</h3>
                    <a href="como-funciona.php">Como funciona</a>
                    <a href="sobre.php">Sobre</a>
                </div>
                <div class="footer-col">
                    <h3>Ajuda</h3>
                    <a href="contato.php">Contacto</a>
                    <a href="login.php">Entrar</a>
                </div>
            </div>
            <div class="footer-bottom">
                <span>© 2026 VolunteerConnect. Projeto demonstrativo.</span>
                <span>A conectar quem quer ajudar a quem precisa.</span>
            </div>
        </div>
    </footer>
</body>
</html>